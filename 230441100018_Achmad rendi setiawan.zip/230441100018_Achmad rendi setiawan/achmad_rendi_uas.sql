-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2024 at 02:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `achmad_rendi_uas`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_dokter`
--

CREATE TABLE `tb_dokter` (
  `nama_dokter` varchar(20) NOT NULL,
  `nik` varchar(15) NOT NULL,
  `keahlian_dokter` varchar(20) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `no_hp` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_dokter`
--

INSERT INTO `tb_dokter` (`nama_dokter`, `nik`, `keahlian_dokter`, `jenis_kelamin`, `alamat`, `no_hp`) VALUES
('ali', '2333', 'Dokter Umum', 'Laki-Laki', 'sambeng', 2311);

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE `tb_login` (
  `username` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_login`
--

INSERT INTO `tb_login` (`username`, `password`) VALUES
('baiq', '0909'),
('rendy', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `tb_obat`
--

CREATE TABLE `tb_obat` (
  `id_kategori` int(10) NOT NULL,
  `nama_obat` varchar(20) NOT NULL,
  `kode_satuan` varchar(10) NOT NULL,
  `jumlah_pesan` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_obat`
--

INSERT INTO `tb_obat` (`id_kategori`, `nama_obat`, `kode_satuan`, `jumlah_pesan`) VALUES
(2, 'amoxilin', 'FF', 8),
(33, 'mixagrip', 'gg', 9),
(123, 'bodrexin', 'GG', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pasien`
--

CREATE TABLE `tb_pasien` (
  `nama` varchar(25) NOT NULL,
  `nik` int(15) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `tempat_lahir` varchar(25) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `tanggal_masuk` date NOT NULL,
  `alamat` varchar(35) NOT NULL,
  `layanan` varchar(20) NOT NULL,
  `tgl_keluar` date DEFAULT NULL,
  `bayar` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_pasien`
--

INSERT INTO `tb_pasien` (`nama`, `nik`, `jenis_kelamin`, `tempat_lahir`, `tgl_lahir`, `tanggal_masuk`, `alamat`, `layanan`, `tgl_keluar`, `bayar`) VALUES
('baiq', 1234, 'Laki-Laki', 'mojokerto ', '2005-11-14', '2024-11-12', 'sidolegi', 'Rawat Jalan', NULL, NULL),
('rendy', 352411, 'Laki-Laki', 'Lamongan', '2005-09-09', '2024-11-14', 'Sambeng', 'Rawat Inap', '2024-11-17', 700);

-- --------------------------------------------------------

--
-- Table structure for table `tb_pegawai`
--

CREATE TABLE `tb_pegawai` (
  `nama_pegawai` varchar(20) NOT NULL,
  `nik` varchar(15) NOT NULL,
  `jenis_pegawai` varchar(15) NOT NULL,
  `sip` varchar(15) NOT NULL,
  `no_hp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tb_pegawai`
--

INSERT INTO `tb_pegawai` (`nama_pegawai`, `nik`, `jenis_pegawai`, `sip`, `no_hp`) VALUES
('faris', '123456', 'Administrasi', 'Malam', '0812');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_dokter`
--
ALTER TABLE `tb_dokter`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`password`);

--
-- Indexes for table `tb_obat`
--
ALTER TABLE `tb_obat`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `tb_pasien`
--
ALTER TABLE `tb_pasien`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `tb_pegawai`
--
ALTER TABLE `tb_pegawai`
  ADD PRIMARY KEY (`nik`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
