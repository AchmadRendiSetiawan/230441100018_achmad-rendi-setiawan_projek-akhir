/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;
import java.sql.ResultSet;
import java.sql.Statement;


public class form_pasien extends javax.swing.JFrame {

    /**
     * Creates new form form_pasien
     */
    
    public form_pasien() {
        initComponents();
        koneksi.getConnection();
        refreshpasien();
        
       
    }

   private void simpanpasien() {
        String sql = "INSERT INTO tb_pasien(nama, nik, jenis_kelamin, tempat_lahir, tgl_lahir, tanggal_masuk, alamat, layanan ) VALUES (?, ?, ?, ?, ?, ?, ?,?)";
        String jkel = "";

        try {
            // Pastikan koneksi valid
            Connection conn = koneksi.getConnection(); 
            if (conn == null) {
                JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!");
                return;
            }

            // Siapkan statement
            PreparedStatement st = conn.prepareStatement(sql);

            // Ambil data dari form
            st.setString(1, txtnama.getText());
            st.setString(2, txtnik.getText());

            // Cek pilihan jenis kelamin
            if (rblk.isSelected()) {
                jkel = "Laki-Laki";
            } else if (rbpr.isSelected()) {
                jkel = "Perempuan";
            }
            st.setString(3, jkel);

            st.setString(4, txtlahir.getText());

            // Validasi dan format tanggal
            if (datetgl.getDate() != null) {
                String tanggal = new SimpleDateFormat("yyyy-MM-dd").format(datetgl.getDate());
                st.setString(5, tanggal);
            } else {
                JOptionPane.showMessageDialog(this, "Tanggal lahir harus diisi!");
                return;
            }
            
            if (datemasuk.getDate() != null) {
                String tanggal = new SimpleDateFormat("yyyy-MM-dd").format(datemasuk.getDate());
                st.setString(6, tanggal);
            } else {
                JOptionPane.showMessageDialog(this, "Tanggal Masuk harus diisi!");
                return;
            }

            st.setString(7, txtalamat.getText());
            st.setString(8, cmblayanan.getSelectedItem().toString());

            // Eksekusi query
            st.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data Pasien Berhasil Disimpan");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Terjadi kesalahan saat menyimpan data: " + e.getMessage());
        }
    }
   
    private void editpasien() {
    String sql = "UPDATE tb_pasien SET nama = ?, nik = ?, jenis_kelamin = ?, tempat_lahir = ?,tgl_lahir = ?,tanggal_masuk = ?,alamat = ?,layanan =? WHERE nik ='"+txtnik.getText()+"'";
    String jkel="";
    try {
        // Mendapatkan koneksi ke database
        Connection conn = koneksi.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!");
            return;
        }

        // Menggunakan PreparedStatement untuk eksekusi query
        PreparedStatement st = conn.prepareStatement(sql);
            
            //ambil data dari form
            st.setString(1, txtnama.getText());
            st.setString(2, txtnik.getText());

            // Cek pilihan jenis kelamin
            if (rblk.isSelected()) {
                jkel = "Laki-Laki";
            } else if (rbpr.isSelected()) {
                jkel = "Perempuan";
            }
            st.setString(3, jkel);

            st.setString(4, txtlahir.getText());

            // Validasi dan format tanggal
            if (datetgl.getDate() != null) {
                String tanggal = new SimpleDateFormat("yyyy-MM-dd").format(datetgl.getDate());
                st.setString(5, tanggal);
            } else {
                JOptionPane.showMessageDialog(this, "Tanggal lahir harus diisi!");
                return;
            }
            
            if (datemasuk.getDate() != null) {
                String tanggal = new SimpleDateFormat("yyyy-MM-dd").format(datemasuk.getDate());
                st.setString(6, tanggal);
            } else {
                JOptionPane.showMessageDialog(this, "Tanggal masuk harus diisi!");
                return;
            }

            st.setString(7, txtalamat.getText());
            st.setString(8, cmblayanan.getSelectedItem().toString());
            st.execute();
            JOptionPane.showMessageDialog(null,"Data pasien Berhasil Di Edit");
            
        } catch (SQLException e) {
        // Menangani kesalahan SQL
        JOptionPane.showMessageDialog(null, e);
    }
}
    
   private void hapuspasien(String pasien) {
    // Query SQL menggunakan parameterized query
    String sql = "DELETE FROM tb_pasien WHERE nik = ?";
    
    try {
        // Mendapatkan koneksi ke database
        Connection conn = koneksi.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!");
            return;
        }
        
        // Menggunakan PreparedStatement
        PreparedStatement st = conn.prepareStatement(sql);
        
        // Mengatur parameter query
        st.setString(1, pasien);

        // Menjalankan query
        int rowsDeleted = st.executeUpdate();
        if (rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Data pasien berhasil dihapus.");
        } else {
            JOptionPane.showMessageDialog(this, "Data dengan nama pasien tersebut tidak ditemukan.");
        }
        
        // Menutup koneksi
        st.close();
        conn.close();
    } catch (SQLException e) {
        // Menangani kesalahan SQL
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}
   
  private void tampilpasien(String pasien) {
    Connection conn = null; // Objek untuk koneksi database
    Statement st = null;    // Untuk menjalankan SQL
    ResultSet rs = null;    // Objek untuk menyimpan hasil SELECT
    
    try {
        // Mendapatkan koneksi dari kelas koneksi
        conn = koneksi.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!");
            return;
        }
        
        // Membuat Statement
        st = conn.createStatement();
        String sql = "SELECT * FROM tb_pasien WHERE nik = '" + pasien + "'";
        
        // Menjalankan query
        rs = st.executeQuery(sql);
        
        // Mengecek jumlah baris yang ditemukan
        if (rs.next()) {
            // Menampilkan data ke text field
            txtnama.setText(rs.getString("nama"));
            txtnik.setText(String.valueOf(rs.getInt("nik")));
            String jkel = rs.getString("jenis_kelamin");
            if (jkel.equalsIgnoreCase("Laki-Laki")) {
                rblk.setSelected(true); 
            } else if (jkel.equalsIgnoreCase("Perempuan")) {
                rbpr.setSelected(true); 
            }
            txtlahir.setText(rs.getString("tempat_lahir"));
            datetgl.setDate(rs.getDate("tgl_lahir"));
            datemasuk.setDate(rs.getDate("tanggal_masuk"));
            txtalamat.setText(rs.getString("alamat"));
            cmblayanan.setSelectedItem(rs.getString("layanan"));

            JOptionPane.showMessageDialog(null, "Data ditemukan.");
            btnedit.setEnabled(true); // Mengaktifkan tombol edit
        } else {
            JOptionPane.showMessageDialog(null, "Data tidak ditemukan.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    } finally {
        // Menutup resource
        try {
            if (rs != null) rs.close();
            if (st != null) st.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error saat menutup koneksi: " + e.getMessage());
        }
    }
}


// Fungsi untuk memuat ulang data dari database ke JTable
private void refreshpasien() {
    String sql = "SELECT * FROM tb_pasien"; // Query untuk mengambil semua data
    try {
        // Mendapatkan koneksi ke database
        Connection conn = koneksi.getConnection();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!");
            return;
        }

        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);

        // Mendapatkan model dari tabel
        DefaultTableModel model = (DefaultTableModel) tblpasien.getModel();

        // Membersihkan tabel sebelum menambahkan data baru
        model.setRowCount(0);

        // Memasukkan data dari ResultSet ke tabel
        while (rs.next()) {
            Object[] row = {
                rs.getString("nama"),     
                rs.getString("nik"),  
                rs.getString("jenis_kelamin"),
                rs.getString("tempat_lahir"), 
                rs.getString("tgl_lahir"),
                 rs.getString("tanggal_masuk"),
                rs.getString("alamat"), 
                rs.getString("layanan"), 
            };
            model.addRow(row);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error saat memuat data: " + e.getMessage());
    }
}

    private void cleardata(){
        txtnama.setText("");
        txtnik.setText("");
        buttonGroup1.clearSelection();
        txtlahir.setText("");
        datetgl.setDate(null);
        datemasuk.setDate(null);
        txtalamat.setText("");
        cmblayanan.setSelectedIndex(0);
        btnedit.setEnabled(false);
        txtnik.setEnabled(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtnama = new javax.swing.JTextField();
        txtnik = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        rblk = new javax.swing.JRadioButton();
        rbpr = new javax.swing.JRadioButton();
        txtlahir = new javax.swing.JTextField();
        datetgl = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtalamat = new javax.swing.JTextArea();
        cmblayanan = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        datemasuk = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        btndaftar = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();
        btnkeluar = new javax.swing.JButton();
        btnrefresh = new javax.swing.JButton();
        btnedit = new javax.swing.JButton();
        btncari = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblpasien = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));

        jLabel1.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("FORM PENDAFTARAN PASIEN");
        jPanel2.add(jLabel1);

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1040, 40));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("__________________________________________________________________________________________________");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, -1, -1));

        jPanel3.setBackground(new java.awt.Color(102, 102, 102));
        jPanel3.setForeground(new java.awt.Color(255, 255, 255));

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nama                    :");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("NIK                        :");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Jenis Kelamin     :");

        jLabel6.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Tempat Lahir       :");

        jLabel7.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Tanggal Lahir      :");

        txtnik.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnikActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Alamat                 :");

        jLabel9.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Jenis Layanan    :");

        buttonGroup1.add(rblk);
        rblk.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        rblk.setForeground(new java.awt.Color(204, 204, 204));
        rblk.setText("Laki-Laki");

        buttonGroup1.add(rbpr);
        rbpr.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        rbpr.setForeground(new java.awt.Color(204, 204, 204));
        rbpr.setText("Perempuan");
        rbpr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbprActionPerformed(evt);
            }
        });

        txtalamat.setColumns(20);
        txtalamat.setRows(5);
        jScrollPane1.setViewportView(txtalamat);

        cmblayanan.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        cmblayanan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Rawat Inap", "Rawat Jalan" }));

        jLabel13.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Tanggal Masuk    : ");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(23, 23, 23))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(datetgl, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtlahir)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(cmblayanan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(datemasuk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(18, 18, 18)
                            .addComponent(rblk)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(rbpr))
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtnama)
                                .addComponent(txtnik)))))
                .addGap(61, 61, 61))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtnama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtnik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(rblk)
                    .addComponent(rbpr))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtlahir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel7))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(datetgl, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(37, 37, 37)
                        .addComponent(jLabel8)
                        .addGap(61, 61, 61))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(datemasuk, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cmblayanan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 340, 420));

        jPanel4.setBorder(javax.swing.BorderFactory.createMatteBorder(2, 2, 2, 2, new java.awt.Color(153, 153, 153)));
        jPanel4.setForeground(new java.awt.Color(255, 255, 255));

        btndaftar.setBackground(new java.awt.Color(51, 102, 255));
        btndaftar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btndaftar.setForeground(new java.awt.Color(255, 255, 255));
        btndaftar.setText("DAFTAR");
        btndaftar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndaftarActionPerformed(evt);
            }
        });

        btnhapus.setBackground(new java.awt.Color(153, 0, 0));
        btnhapus.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnhapus.setForeground(new java.awt.Color(255, 255, 255));
        btnhapus.setText("HAPUS");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });

        btnkeluar.setBackground(new java.awt.Color(51, 153, 255));
        btnkeluar.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnkeluar.setForeground(new java.awt.Color(255, 255, 255));
        btnkeluar.setText("KELUAR");
        btnkeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnkeluarActionPerformed(evt);
            }
        });

        btnrefresh.setBackground(new java.awt.Color(204, 255, 204));
        btnrefresh.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnrefresh.setText("Refresh");
        btnrefresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrefreshActionPerformed(evt);
            }
        });

        btnedit.setBackground(new java.awt.Color(204, 255, 0));
        btnedit.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnedit.setText("Edit");
        btnedit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneditActionPerformed(evt);
            }
        });

        btncari.setFont(new java.awt.Font("Rockwell", 0, 14)); // NOI18N
        btncari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/search.png"))); // NOI18N
        btncari.setText("  CARI DATA");
        btncari.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        btncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncariActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btncari, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addComponent(btndaftar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(btnhapus)
                        .addGap(18, 18, 18)
                        .addComponent(btnedit, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addComponent(btnrefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(btnkeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(29, 29, 29))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndaftar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnhapus, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnedit, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnrefresh, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnkeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addComponent(btncari)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 510, 340, 160));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel10.setText("_______________________________________________________________________________________________________________________________________________");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, -1, -1));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        tblpasien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nama", "NIK", "Jenis_kelamin", "Tempat_Lahir", "Tanggal_lahir", "Tanggal_masuk", "Alamat", "Jenis_layanan"
            }
        ));
        jScrollPane2.setViewportView(tblpasien);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 658, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 670, 370));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/medical-checkup-removebg-preview.png"))); // NOI18N
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 500, 130, 130));

        jLabel12.setFont(new java.awt.Font("Script MT Bold", 0, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Rumah Sakit Sehat Tentram");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 560, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1041, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 678, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnikActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnikActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnikActionPerformed

    private void rbprActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbprActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbprActionPerformed

    private void btndaftarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndaftarActionPerformed
        // TODO add your handling code here:
        simpanpasien();
        refreshpasien();
        cleardata();
    }//GEN-LAST:event_btndaftarActionPerformed

    private void btnkeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnkeluarActionPerformed
        // TODO add your handling code here:
        int jawab=javax.swing.JOptionPane.showConfirmDialog(null, "Yakin mau keluar?","Konfirmasi",
                javax.swing.JOptionPane.YES_NO_CANCEL_OPTION);
        if (jawab==0);
        this.dispose();
    }//GEN-LAST:event_btnkeluarActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
        // TODO add your handling code here:
          // Meminta input nama pasien
    String nik_pasien = JOptionPane.showInputDialog(this, "Silahkan Masukkan Nik Pasien yang Akan Dihapus:");

    // Validasi input
    if (nik_pasien == null || nik_pasien.trim().isEmpty()) {
        JOptionPane.showMessageDialog(this, "Nik pasien tidak boleh kosong!");
        return;
    }

    // Konfirmasi penghapusan
    int jwb = JOptionPane.showConfirmDialog(this, 
        "Yakin ingin menghapus data dokter dengan nik: " + nik_pasien + "?", 
        "Konfirmasi Hapus", 
        JOptionPane.YES_NO_OPTION);

    if (jwb == JOptionPane.YES_OPTION) {
        // Panggil fungsi hapuspasien
        hapuspasien(nik_pasien);

        // Perbarui tabel
        refreshpasien(); // Pastikan Anda memiliki fungsi untuk memuat ulang data ke tabel
    }
    }//GEN-LAST:event_btnhapusActionPerformed

    private void btnrefreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrefreshActionPerformed
        // TODO add your handling code here:
        this.requestFocus();
        cleardata();
    }//GEN-LAST:event_btnrefreshActionPerformed

    private void btneditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneditActionPerformed
        // TODO add your handling code here:
        editpasien();
        refreshpasien();
    }//GEN-LAST:event_btneditActionPerformed

    private void btncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncariActionPerformed
        // TODO add your handling code here:
        String strInput=JOptionPane.showInputDialog("Silahkan Masukkan Nik Pasien Yang Akan Di Cari");
        txtnik.setEnabled(false);
        tampilpasien(strInput);
    }//GEN-LAST:event_btncariActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(form_pasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(form_pasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(form_pasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(form_pasien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new form_pasien().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncari;
    private javax.swing.JButton btndaftar;
    private javax.swing.JButton btnedit;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnrefresh;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cmblayanan;
    private com.toedter.calendar.JDateChooser datemasuk;
    private com.toedter.calendar.JDateChooser datetgl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rblk;
    private javax.swing.JRadioButton rbpr;
    private javax.swing.JTable tblpasien;
    private javax.swing.JTextArea txtalamat;
    private javax.swing.JTextField txtlahir;
    private javax.swing.JTextField txtnama;
    private javax.swing.JTextField txtnik;
    // End of variables declaration//GEN-END:variables
}
